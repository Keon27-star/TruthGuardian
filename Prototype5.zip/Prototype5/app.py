from flask import Flask, request, jsonify, render_template, redirect, url_for, flash, session
import random
import re
import requests
from werkzeug.security import generate_password_hash, check_password_hash
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import torch
from transformers import RobertaForSequenceClassification, RobertaTokenizer

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Change this to a random secret key for session management
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.db'  # SQLite database
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

# User model
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)
    first_name = db.Column(db.String(50), nullable=False)
    last_name = db.Column(db.String(50), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_active = db.Column(db.Boolean, default=True)

    def __repr__(self):
        return f'<User {self.first_name} {self.last_name} - {self.email}>'

# Create the database tables
with app.app_context():
    db.create_all()

# Sample data for dashboard topics
topics = ["Politics", "Health", "Technology", "Environment", "Sports", "Entertainment", "Finance", "Education", "Science", "Travel"]

# Define your News API key here
NEWS_API_KEY = '6885ff3b571a406087dc07c780f8cbf3'  # Replace with your actual News API key

# Predefined trends with keyword pairs
trend_keywords = {
    "AI advancements": ["Machine Learning", "Deep Learning", "Neural Networks", "Artificial Intelligence", "AI Research"],
    "Climate Change": ["Global Warming", "Carbon Emissions", "Renewable Energy", "Sustainable Development"],
    "Healthcare": ["COVID-19", "Mental Health", "Vaccines", "Health Innovations", "Medical Breakthroughs"],
    "Cryptocurrency": ["Bitcoin", "Blockchain", "Ethereum", "NFTs", "Smart Contracts"],
    "Cybersecurity": ["Phishing", "Malware", "Ransomware", "Data Breaches", "Hacking"],
    "Space Exploration": ["Mars Mission", "NASA", "SpaceX", "Astronomy", "Satellites"]
}

# Load RoBERTa model and tokenizer for news classification
tokenizer = RobertaTokenizer.from_pretrained('roberta-base')
model = RobertaForSequenceClassification.from_pretrained('roberta-base', num_labels=2)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['username']
        password = request.form['password']
        
        user = User.query.filter_by(email=email).first()
        if user and check_password_hash(user.password, password):
            session['username'] = email
            flash('Login successful!', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid credentials, please try again.', 'danger')
    
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        first_name = request.form['first_name']
        last_name = request.form['last_name']
        
        if User.query.filter_by(email=email).first():
            flash('Email already registered. Please log in.', 'warning')
            return redirect(url_for('login'))

        hashed_password = generate_password_hash(password, method='sha256')
        new_user = User(email=email, password=hashed_password, first_name=first_name, last_name=last_name)
        db.session.add(new_user)
        db.session.commit()
        flash('Registration successful! Please log in.', 'success')
        return redirect(url_for('login'))

    return render_template('register.html')

@app.route('/dashboard')
def dashboard():
    return render_template('dashboard.html', topics=topics)

@app.route('/about')  # Add the About Us route here
def about():
    """Serve the About Us page."""
    return render_template('about.html')

@app.route('/fetch_news', methods=['GET'])
def fetch_news():
    topic = request.args.get('topic', '')
    if not topic:
        return jsonify({"error": "Topic is required to fetch news."}), 400
    
    url = f'https://newsapi.org/v2/everything?q={topic}&apiKey={NEWS_API_KEY}'
    
    response = requests.get(url)
    if response.status_code == 200:
        articles = response.json().get('articles', [])
        return jsonify(articles)
    else:
        return jsonify({"error": "Failed to fetch news."}), 500

@app.route('/check_trust', methods=['POST'])
def check_trust():
    data = request.json
    website = data.get("website_url", "").replace("https://", "").replace("http://", "").split("/")[0]

    if not website:
        return jsonify({"error": "Invalid website URL"}), 400

    result = TRUST_SCORES.get(website, {"score": 50, "verdict": "Unknown"}) # type: ignore

    return jsonify({
        "website": website,
        "trust_score": result["score"],
        "verdict": result["verdict"]
    })

# News classification function using RoBERTa
def classify_news(news_text):
    # Debugging: Log the received text
    print(f"Received news text: {news_text}")

    inputs = tokenizer(news_text, return_tensors="pt", truncation=True, padding=True, max_length=512)
    with torch.no_grad():
        logits = model(**inputs).logits
    
    prediction = torch.argmax(logits, dim=-1).item()
    category = "Real" if prediction == 0 else "Fake"
    
    confidence = round(torch.nn.functional.softmax(logits, dim=-1)[0][prediction].item() * 100, 2)
    accuracy = random.randint(70, 100)  # Simulating accuracy score
    reason = f"Confidence: {confidence}%"

    # Debugging: Log the classification result
    print(f"Classification Result - Category: {category}, Confidence: {confidence}, Accuracy: {accuracy}, Reason: {reason}")
    
    return category, confidence, accuracy, reason

@app.route('/check_news', methods=['POST'])
def check_news():
    try:
        news_text = request.json.get('news_text', '').strip()

        # Debugging input validation
        print(f"Received news text: {news_text}")
        
        if len(news_text) < 20 or not re.search(r'[a-zA-Z]', news_text):
            return jsonify({"error": "Invalid input. Please enter meaningful text with real words."}), 400

        category, confidence, accuracy, reason = classify_news(news_text)

        # Debugging classification result
        print(f"Classification Result - Category: {category}, Confidence: {confidence}, Accuracy: {accuracy}, Reason: {reason}")

        return jsonify({
            "category": category,
            "confidence": confidence,
            "accuracy": accuracy,
            "reason": reason
        })
    except Exception as e:
        print(f"Error: {str(e)}")  # Log error
        return jsonify({"error": str(e)}), 500

@app.route('/trends')
def trends_page():
    # Generate a random trend and related keywords from the trend_keywords dictionary
    selected_trend = random.choice(list(trend_keywords.items()))
    trend_name, related_keywords = selected_trend

    return render_template('trends.html', trend_name=trend_name, keywords=related_keywords)

@app.route('/fetch_trends', methods=['GET'])
def fetch_trends():
    """Fetch trend data for a specific topic."""
    topic = request.args.get('topic', '')
    if not topic:
        return jsonify({"error": "Topic is required to fetch trends."}), 400

    # Simulate fetching trend data (replace this with actual logic)
    # For example, you could fetch data from a database or an external API
    trend_data = []
    for i in range(10):  # Simulating 10 days of trend data
        trend_data.append({
            "date": f"2023-10-{i+1:02d}",  # Simulated date
            "count": random.randint(1, 100),  # Simulated count of mentions
            "sentiment": random.choice(["positive", "negative", "neutral"])  # Simulated sentiment
        })

    return jsonify(trend_data)

@app.route('/verify_source', methods=['POST'])
def verify_source():
    try:
        source_url = request.json.get('source_url', '').strip()

        if not source_url:
            return jsonify({"error": "Please provide a URL."}), 400
        
        # Simulate some verification logic (for testing purposes)
        credibility_score = random.randint(0, 100)
        reputation = random.choice(["Good", "Neutral", "Poor"])
        verified = "Yes" if credibility_score >= 50 else "No"
        category = random.choice(["News", "Blog", "Advertisement", "Opinion"])
        accuracy = round(random.uniform(50, 100), 2)

        return jsonify({
            "source_verified": verified,
            "category": category,
            "credibility_score": credibility_score,
            "reputation": reputation,
            "accuracy": accuracy,
            "historical_data": "This source has a mixed reputation."
        })

    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/submit_feedback', methods=['POST'])
def submit_feedback():
    try:
        feedback = request.json.get('feedback', '').strip()

        if not feedback:
            return jsonify({"error": "Feedback cannot be empty."}), 400
        
        with open('feedback.txt', 'a') as f:
            f.write(feedback + '\n')

        return jsonify({"message": "Thank you for your feedback!"}), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/logout')
def logout():
    session.pop('username', None)
    flash('You have been logged out.', 'info')
    return redirect(url_for('home'))

@app.route('/users')
def view_users():
    users = User.query.all()
    return render_template('view_users.html', users=users)

if __name__ == '__main__':
    app.run(debug=True)
